function boardGamesHandler() {
    const baseUrl = "http://localhost:3030/jsonstore/games";
    const [gameNameInput, gameTypeInput, maxPlayersInput, addGameButton, editGameButton] = document.querySelectorAll("#form-section #form input, #form-section #form button");
    const loadGamesButton = document.querySelector("#games #load-games");
    const gamesContainer = document.querySelector("#games #games-list");
    const gameTemplate = document.querySelector(".board-game");
    gameTemplate.remove();

    loadGamesButton.addEventListener("click", loadGames);

    async function loadGames() {
        gamesContainer.innerHTML = "";
        let games = await fetch(baseUrl);
        editGameButton.setAttribute("disabled", "disabled");
        games = await games.json();
        Object.values(games).forEach(game => {
            serveGame(
                game.name,
                game.type,
                game.players,
                (e) => changeFunction(e, game._id, game.name, game.type, game.players),
                (e) => deleteFunction(game._id)
            );
        });
    }

    addGameButton.addEventListener("click", async (e) => {
        await addGame();
        loadGames();
    });

    function changeFunction(e, id, name, type, players) {
        gameNameInput.value = name;
        gameTypeInput.value = type;
        maxPlayersInput.value = players;
        e.target.parentElement.parentElement.remove();
        addGameButton.setAttribute("disabled", "disabled");
        editGameButton.removeAttribute("disabled");
        editGameButton.addEventListener("click", async (e) => {
            await editGame(id);
            loadGames();
            editGameButton.setAttribute("disabled", "disabled");
            addGameButton.removeAttribute("disabled");
        }, { once: true });
    }

    async function deleteFunction(id) {
        await fetch(`${baseUrl}/${id}`, {
            method: "DELETE"
        });
        loadGames();
    }

    function serveGame(name, type, players, changeFunc, delFunc) {
        const gameElem = gameTemplate.cloneNode(true);
        const [nameElem, typeElem, playersElem, changeButton, deleteButton] = gameElem.querySelectorAll("p, button");
        nameElem.textContent = name;
        typeElem.textContent = type;
        playersElem.textContent = players;
        changeButton.addEventListener("click", changeFunc);
        deleteButton.addEventListener("click", delFunc);
        gamesContainer.appendChild(gameElem);
    }

    async function addGame(gameId = false) {
        const [name, type, players] = [gameNameInput.value, gameTypeInput.value, maxPlayersInput.value];
        if (![name, type, players].every(value => value)) return;
        const method = gameId ? "PUT" : "POST";
        let url = baseUrl;
        if (method === "PUT") url += `/${gameId}`;
        const body = { name, type, players };
        if (gameId) body._id = gameId;
        await fetch(url, {
            method,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body)
        });
        clearFields();
    }

    function clearFields() {
        gameNameInput.value = "";
        gameTypeInput.value = "";
        maxPlayersInput.value = "";
    }

    async function editGame(id) {
        await addGame(id);
    }
}

boardGamesHandler();
